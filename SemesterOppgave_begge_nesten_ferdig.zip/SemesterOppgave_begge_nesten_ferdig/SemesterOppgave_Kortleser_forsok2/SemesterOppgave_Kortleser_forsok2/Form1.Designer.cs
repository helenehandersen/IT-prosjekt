﻿namespace SemesterOppgave_Kortleser_forsok2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSettInnKort = new System.Windows.Forms.Button();
            this.lbDørStatus = new System.Windows.Forms.ListBox();
            this.lbAlarmStatus = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lbFeilMeldinger = new System.Windows.Forms.ListBox();
            this.btnLukkDør = new System.Windows.Forms.Button();
            this.btnÅpneDør = new System.Windows.Forms.Button();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.cbSeriellePorter = new System.Windows.Forms.ComboBox();
            this.txtTid = new System.Windows.Forms.TextBox();
            this.btn0 = new System.Windows.Forms.Button();
            this.btn1 = new System.Windows.Forms.Button();
            this.btn2 = new System.Windows.Forms.Button();
            this.btn3 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtKortID = new System.Windows.Forms.TextBox();
            this.txtPinKode = new System.Windows.Forms.TextBox();
            this.backgroundWorker2 = new System.ComponentModel.BackgroundWorker();
            this.SuspendLayout();
            // 
            // btnSettInnKort
            // 
            this.btnSettInnKort.Location = new System.Drawing.Point(142, 9);
            this.btnSettInnKort.Name = "btnSettInnKort";
            this.btnSettInnKort.Size = new System.Drawing.Size(94, 29);
            this.btnSettInnKort.TabIndex = 0;
            this.btnSettInnKort.Text = "Sett inn";
            this.btnSettInnKort.UseVisualStyleBackColor = true;
            this.btnSettInnKort.Click += new System.EventHandler(this.btnSettInnKort_Click);
            // 
            // lbDørStatus
            // 
            this.lbDørStatus.FormattingEnabled = true;
            this.lbDørStatus.ItemHeight = 20;
            this.lbDørStatus.Location = new System.Drawing.Point(9, 221);
            this.lbDørStatus.Name = "lbDørStatus";
            this.lbDørStatus.Size = new System.Drawing.Size(506, 104);
            this.lbDørStatus.TabIndex = 1;
            // 
            // lbAlarmStatus
            // 
            this.lbAlarmStatus.FormattingEnabled = true;
            this.lbAlarmStatus.ItemHeight = 20;
            this.lbAlarmStatus.Location = new System.Drawing.Point(12, 364);
            this.lbAlarmStatus.Name = "lbAlarmStatus";
            this.lbAlarmStatus.Size = new System.Drawing.Size(506, 104);
            this.lbAlarmStatus.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(127, 20);
            this.label1.TabIndex = 3;
            this.label1.Text = "Sett inn kort/Tapp";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(351, 13);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(30, 20);
            this.label2.TabIndex = 4;
            this.label2.Text = "Tid";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 474);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(103, 20);
            this.label3.TabIndex = 5;
            this.label3.Text = "Serielle porter";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 341);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(91, 20);
            this.label4.TabIndex = 6;
            this.label4.Text = "Alarm status";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(9, 198);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(76, 20);
            this.label5.TabIndex = 7;
            this.label5.Text = "Dør status";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(560, 26);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(100, 20);
            this.label6.TabIndex = 8;
            this.label6.Text = "Feilmeldinger";
            // 
            // lbFeilMeldinger
            // 
            this.lbFeilMeldinger.FormattingEnabled = true;
            this.lbFeilMeldinger.ItemHeight = 20;
            this.lbFeilMeldinger.Location = new System.Drawing.Point(560, 56);
            this.lbFeilMeldinger.Name = "lbFeilMeldinger";
            this.lbFeilMeldinger.Size = new System.Drawing.Size(218, 364);
            this.lbFeilMeldinger.TabIndex = 12;
            // 
            // btnLukkDør
            // 
            this.btnLukkDør.Location = new System.Drawing.Point(424, 109);
            this.btnLukkDør.Name = "btnLukkDør";
            this.btnLukkDør.Size = new System.Drawing.Size(94, 29);
            this.btnLukkDør.TabIndex = 15;
            this.btnLukkDør.Text = "Lukk dør";
            this.btnLukkDør.UseVisualStyleBackColor = true;
            this.btnLukkDør.Click += new System.EventHandler(this.btnLukkDør_Click_1);
            // 
            // btnÅpneDør
            // 
            this.btnÅpneDør.Location = new System.Drawing.Point(324, 109);
            this.btnÅpneDør.Name = "btnÅpneDør";
            this.btnÅpneDør.Size = new System.Drawing.Size(94, 29);
            this.btnÅpneDør.TabIndex = 16;
            this.btnÅpneDør.Text = "Åpne dør";
            this.btnÅpneDør.UseVisualStyleBackColor = true;
            this.btnÅpneDør.Click += new System.EventHandler(this.btnÅpneDør_Click_1);
            // 
            // backgroundWorker1
            // 
            this.backgroundWorker1.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundWorker1_DoWork);
            this.backgroundWorker1.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.backgroundWorker1_RunWorkerCompleted);
            // 
            // cbSeriellePorter
            // 
            this.cbSeriellePorter.FormattingEnabled = true;
            this.cbSeriellePorter.Location = new System.Drawing.Point(121, 474);
            this.cbSeriellePorter.Name = "cbSeriellePorter";
            this.cbSeriellePorter.Size = new System.Drawing.Size(151, 28);
            this.cbSeriellePorter.TabIndex = 17;
            // 
            // txtTid
            // 
            this.txtTid.Location = new System.Drawing.Point(393, 13);
            this.txtTid.Name = "txtTid";
            this.txtTid.ReadOnly = true;
            this.txtTid.Size = new System.Drawing.Size(125, 27);
            this.txtTid.TabIndex = 18;
            this.txtTid.TextChanged += new System.EventHandler(this.txtTid_TextChanged);
            // 
            // btn0
            // 
            this.btn0.Location = new System.Drawing.Point(9, 79);
            this.btn0.Name = "btn0";
            this.btn0.Size = new System.Drawing.Size(94, 29);
            this.btn0.TabIndex = 19;
            this.btn0.Text = "0";
            this.btn0.UseVisualStyleBackColor = true;
            this.btn0.Click += new System.EventHandler(this.btn0_Click);
            // 
            // btn1
            // 
            this.btn1.Location = new System.Drawing.Point(109, 79);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(94, 29);
            this.btn1.TabIndex = 20;
            this.btn1.Text = "1";
            this.btn1.UseVisualStyleBackColor = true;
            this.btn1.Click += new System.EventHandler(this.btn1_Click);
            // 
            // btn2
            // 
            this.btn2.Location = new System.Drawing.Point(9, 114);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(94, 29);
            this.btn2.TabIndex = 21;
            this.btn2.Text = "2";
            this.btn2.UseVisualStyleBackColor = true;
            this.btn2.Click += new System.EventHandler(this.btn2_Click);
            // 
            // btn3
            // 
            this.btn3.Location = new System.Drawing.Point(109, 114);
            this.btn3.Name = "btn3";
            this.btn3.Size = new System.Drawing.Size(94, 29);
            this.btn3.TabIndex = 22;
            this.btn3.Text = "3";
            this.btn3.UseVisualStyleBackColor = true;
            this.btn3.Click += new System.EventHandler(this.btn3_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(18, 58);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 20);
            this.label7.TabIndex = 23;
            this.label7.Text = "PIN tastatur";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(304, 58);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(83, 20);
            this.label8.TabIndex = 24;
            this.label8.Text = "Ditt kort ID";
            // 
            // txtKortID
            // 
            this.txtKortID.Location = new System.Drawing.Point(393, 55);
            this.txtKortID.Name = "txtKortID";
            this.txtKortID.ReadOnly = true;
            this.txtKortID.Size = new System.Drawing.Size(125, 27);
            this.txtKortID.TabIndex = 25;
            this.txtKortID.TextChanged += new System.EventHandler(this.txtKortID_TextChanged);
            // 
            // txtPinKode
            // 
            this.txtPinKode.Location = new System.Drawing.Point(45, 149);
            this.txtPinKode.Name = "txtPinKode";
            this.txtPinKode.Size = new System.Drawing.Size(125, 27);
            this.txtPinKode.TabIndex = 26;
            this.txtPinKode.TextChanged += new System.EventHandler(this.txtPinKode_TextChanged);
            // 
            // backgroundWorker2
            // 
            this.backgroundWorker2.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundWorker2_DoWork);
            this.backgroundWorker2.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.backgroundWorker2_RunWorkerCompleted);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 525);
            this.Controls.Add(this.txtPinKode);
            this.Controls.Add(this.txtKortID);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.btn3);
            this.Controls.Add(this.btn2);
            this.Controls.Add(this.btn1);
            this.Controls.Add(this.btn0);
            this.Controls.Add(this.txtTid);
            this.Controls.Add(this.cbSeriellePorter);
            this.Controls.Add(this.btnÅpneDør);
            this.Controls.Add(this.btnLukkDør);
            this.Controls.Add(this.lbFeilMeldinger);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbAlarmStatus);
            this.Controls.Add(this.lbDørStatus);
            this.Controls.Add(this.btnSettInnKort);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button btnSettInnKort;
        private ListBox lbDørStatus;
        private ListBox lbAlarmStatus;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private ListBox lbFeilMeldinger;
        private Button btnLukkDør;
        private Button btnÅpneDør;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private ComboBox cbSeriellePorter;
        private TextBox txtTid;
        private Button btn0;
        private Button btn1;
        private Button btn2;
        private Button btn3;
        private Label label7;
        private Label label8;
        private TextBox txtKortID;
        private TextBox txtPinKode;
        private System.ComponentModel.BackgroundWorker backgroundWorker2;
    }
}