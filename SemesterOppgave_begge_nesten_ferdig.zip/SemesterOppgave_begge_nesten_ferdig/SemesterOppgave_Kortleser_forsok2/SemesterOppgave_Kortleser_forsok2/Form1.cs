using System.IO.Ports;
using System.Net.Sockets;
using System.Net;
using System.Threading.Tasks;
using System.Text;

namespace SemesterOppgave_Kortleser_forsok2
{
    public partial class Form1 : Form
    {
        string tekstSomSkalSendes, mottattTekst;
        bool ferdig;
        string dataFraServer;
        Socket klientSokkel;
        bool kommuniser;
        SerialPort sp;
        string enMelding;
        string data;
        int TidIgjen;
        string PIN;
        string tidOgDato;
        int kj�ringer;
        string d�rNummer;
        bool d�r�pen;
        int tidD�r�pen;
        bool pinRiktig;
        string[] tKortID = new string[4];
        string[] lKortID;
        string[] lPIN;
        string kortID;
        bool tast0;
        bool tast1;
        bool tast2;
        bool tast3;
        bool enHelMeldingMotatt;
        Random r = new Random();
        bool tappetKort;
        string tidligereKortID;
        string tidligerPIN;
        public Form1()
        {
            InitializeComponent();

            OppdaterSeriellePorter();                   //Viser oss ledige porter

            d�rNummer = "F103";

            kj�ringer = -1;
            mottattTekst = "";
            ferdig = false;
            klientSokkel = null;
            dataFraServer = "";
            kommuniser = false;
            TidIgjen = 45;
            btnLukkD�r.Enabled = false;
            btn�pneD�r.Enabled = true;
            d�r�pen = false;
            tidD�r�pen = 0;
            pinRiktig = false;
            tast0 = false;
            tast1 = false;
            tast2 = false;
            tast3 = false;
            enHelMeldingMotatt = false;

            tKortID[0] = "0000";
            tKortID[1] = "1111";
            tKortID[2] = "2222";
            tKortID[3] = "3333";

            tappetKort = false;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void backgroundWorker1_DoWork(object sender, System.ComponentModel.DoWorkEventArgs e)
        {
            // Utf�res av en hjelpetr�d n�r RunWorkerAsync-brukes

            enMelding = "";

            if (tappetKort)                                             //Hvis btnSettInnKort er trykket og umulig � trykke p�
            {
                Thread.Sleep(1000);                                     //Thread.Sleep(1000) for � telle ned 1 sekund om gangen
                TidIgjen--;                                             //Teller nedover
            }

            if (d�r�pen)                                                //Hvis d�r �pen (bool) er true
            {
                Thread.Sleep(1000);                                     //Teller hvert sekund
                tidD�r�pen++;                                           //Teller oppover
            }
            else
            {
                tidD�r�pen = 0;                                         //Hvis d�ren lukkes/ikke �pnes, blir tiden 0
            }

            while (kommuniser && !enHelMeldingMotatt)                   //Gj�r at vi kontinuerlig kommuniserer med SimSim
            {
                data = data + MottaData(sp);                            //Legger til meldinger fra SimSim i stringen


                if (DataInneholderEnHelMelding(data))                   //Sjekker at vi leser hele meldingen
                {

                    data = HenteUtEnMelding(data, ref enMelding);       //Henter ut meldingen

                    enHelMeldingMotatt = true;                          //Gir oss en boolsk verdi for om meldingen er mottatt
                }
            }
        }

        private void backgroundWorker1_RunWorkerCompleted(object sender, System.ComponentModel.RunWorkerCompletedEventArgs e)
        {

            backgroundWorker1.RunWorkerAsync();                         //Gj�r at nedtellingen fungerer kontinuerlig

            if (tappetKort)                                             //Hvis btnSettInnKort er trykket
            {
                txtTid.Text = Convert.ToString(TidIgjen);               //Konventerer tid til tekst for � skrive det til tekstboksen
                txtPinKode.Text = PIN;
                if (TidIgjen <= 0)                                      //Hvis tiden er g�tt ut
                {
                    SendEnMelding(sp, "$O40");                          //Setter utgang til 0 at kortet ikke er tappet
                    btnSettInnKort.Enabled = true;                      //Gj�r det mulig � trykke p� knappen igjen
                    TidIgjen = 45;                                      //Setter tiden tilbake til 45 for nytt fors�k
                    kommuniser = false;
                    tappetKort = false;
                    sp.Close();                                         //Lukker koblingen s� ingenting g�r feil for neste bruker
                }
            }
            else
            {
                txtTid.Text = "";                                       //Fjerner tiden fra nedtellings vinduet
            }


            if (tidD�r�pen >= 10)                                       //Hvis d�ren er �pen i mer ennn 10 sekunder vil alarmen g�
            {
                lbAlarmStatus.Items.Insert(0, "D�r v�rt �pen for lenge!");    //Legger til i alarmstatus at d�ren har v�rt �pen for lenge
                tidD�r�pen = -1000000;                                        //Setter tiden langt ned slik at vi ikke f�r flere alarmer
                SendEnMelding(sp, "$O71");                                    //Skriver til utgang i SimSim at alarmen har g�tt

                tekstSomSkalSendes = "Alarm1" + "," + tidligerPIN + "," + "1234" + "," + tidligereKortID + "," + "2022-11-09 12:46:22" + "," + d�rNummer;     //Sender melding til Sentral
                backgroundWorker2.RunWorkerAsync();                           //Starter bw2 for � sende meldingen
            }

            if (tast0)                                                  //Skriver til SimSim at vi tast 0 er trykket
            {
                SendEnMelding(sp, "$O01");
                tast0 = false;
                if (enHelMeldingMotatt) SendEnMelding(sp, "$O00");      //Setter den til 0 igjen etter motatt melding fra SimSim
            }
            if (tast1)
            {
                SendEnMelding(sp, "$O11");
                tast1 = false;
                if (enHelMeldingMotatt) SendEnMelding(sp, "$O10");
            }
            if (tast2)
            {
                SendEnMelding(sp, "$O21");
                tast2 = false;
                if (enHelMeldingMotatt) SendEnMelding(sp, "$O20");
            }
            if (tast3)
            {
                SendEnMelding(sp, "$O31");
                tast3 = false;
                if (enHelMeldingMotatt) SendEnMelding(sp, "$O30");
            }
        }
        static Socket KobleTilServer(out bool ferdig)
        {
            ferdig = false;
            Socket klientSokkel = new Socket(AddressFamily.InterNetwork,
                SocketType.Stream,
                ProtocolType.Tcp);

            IPEndPoint serverEP = new IPEndPoint(IPAddress.Parse("127.0.0.1"), 9050);

            try
            {
                klientSokkel.Connect(serverEP); // blokkerende metode
            }
            catch (SocketException unntak)
            {
                ferdig = true;
            }

            return klientSokkel;
        }

        static string MottaTekst(Socket kommSokkel, out bool feilHarOppst�tt)
        {
            string svar = "";
            feilHarOppst�tt = false;

            try
            {
                byte[] data = new byte[1024];
                int antallBytesMottatt = kommSokkel.Receive(data);

                if (antallBytesMottatt > 0) svar = Encoding.ASCII.GetString(data, 0, antallBytesMottatt);
                else feilHarOppst�tt = true;
            }
            catch (Exception unntak)
            {
                MessageBox.Show("Feil: " + unntak.ToString());
                feilHarOppst�tt = true;
            }
            return svar;
        }

        static void SendTekst(Socket kommSokkel, string tekstSomSkalSendes, out bool feilHarOppst�tt)
        {
            feilHarOppst�tt = false;

            try
            {
                byte[] data = Encoding.ASCII.GetBytes(tekstSomSkalSendes);
                kommSokkel.Send(data, data.Length, SocketFlags.None);
            }
            catch (Exception unntak)
            {
                MessageBox.Show("Feil: " + unntak.ToString());
                feilHarOppst�tt = true;
            }
        }

        void OppdaterSeriellePorter()
        {
            string[] allePorter = SerialPort.GetPortNames();
            for (int i = 0; i < allePorter.Length; i++)
            {
                cbSeriellePorter.Items.Add(allePorter[i]);
            }
            if (cbSeriellePorter.Items.Count > 0)
            {
                cbSeriellePorter.SelectedIndex = 0;
            }
        }

        void SeriellPortKommunikasjon(object o)
        {

            string comPort = o as string;


        }

        static string HenteUtEnMelding(string data, ref string enMelding)
        {
            int posStart = data.IndexOf('$');                                               //Alle meldingene starter med $
            int posSlutt = data.IndexOf('#');                                               //Alle meldinge slutter med #

            enMelding = data.Substring(posStart, (posSlutt - posStart) + 1);                //Klipper ut meldingen mellom start og slutt, s� vi ikke f�r u�nsket melding med 

            if (posStart > 0) data = data.Substring(posStart);                              // Klipper vekk eventuelle tegn f�r $

            if (enMelding.Length < data.Length) data = data.Substring(posSlutt + 1);        // Bevarer til senere bruk eventuelle tegn etter #
            else data = "";
            return data;
        }

        static bool DataInneholderEnHelMelding(string data)
        {
            bool svar = false;                                                               //En boolsk variabel for � indikere om hele meldingen er motatt

            int posStart = data.IndexOf('$');
            int posSlutt = data.IndexOf('#');
            if (posStart != -1 && posSlutt != -1)                                           //Sjekker at b�de start og slutt tegnet er med i meldingen
            {
                if (posStart < posSlutt)                                                    //Hvis posStart er mindre en posSlutt vil det si at vi ikke har begynt � lese meldingen midt inni
                {
                    svar = true;
                }
            }
            return svar;                                                                    //Retunerer svaret om vi har lest hele meldingen eller ikke
        }

        static string MottaData(SerialPort sp)
        {
            string svar = "";                                                               //String vi �nsker � retunere fra metoden
            try
            {
                svar = sp.ReadExisting();                                                   //Leser filen vi har �pnet fra SerialPort
            }
            catch (Exception unntak)
            {

            }
            return svar;
        }

        static void SendEnMelding(SerialPort s, string melding)
        {
            try
            {
                s.Write(melding);                                                           //Skriver melding til serieporten i try catch
            }
            catch (Exception unntak)
            {

            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            backgroundWorker1.RunWorkerAsync();                         //Starter bw1 for � starte telling og andre aksjoner

            klientSokkel = KobleTilServer(out ferdig);
            if (ferdig)
            {
                lbFeilMeldinger.Items.Insert(0, "Feil har skjedd i mottak av tekst");
            }
            if (!ferdig)
            {
                string velkomstmelding = MottaTekst(klientSokkel, out ferdig);
                if (ferdig) Application.Exit();
                else
                {
                    lbFeilMeldinger.Items.Insert(0, velkomstmelding);
                }
            }
        }

        private void btnSettInnKort_Click(object sender, EventArgs e)
        {
            kj�ringer++;
            btnSettInnKort.Enabled = false;                             //Gj�r det umulig � trykke p� nye tapping av kort
            tappetKort = true;

            txtKortID.Text = tKortID[r.Next(0, 3)];      //Viser kort ID
            kortID = txtKortID.Text;

            lKortID[kj�ringer] = kortID;
            lbD�rStatus.Items.Insert(0, kortID + " �nsker tilgang");        //Viser brukergrensesnittet n�v�rende og tidligere kortID foresp�rsler

            if (cbSeriellePorter.SelectedIndex >= 0)
            {
                string comPort = cbSeriellePorter.SelectedItem.ToString();
                kommuniser = true;

                sp = new SerialPort(comPort, 9600);

                try
                {
                    sp.Open();
                }
                catch (Exception unntak)
                {

                }

                if (sp.IsOpen)
                {
                    SendEnMelding(sp, "$S001");                     //Endre tidsintervallet til 1 sek
                    Thread.Sleep(200);
                    SendEnMelding(sp, "$O41");                      //Skrur p� utgang 4 siden kortet er tappet
                    Thread.Sleep(200);
                    SendEnMelding(sp, "$O70");                      //Skrur av alarm utgang
                    Thread.Sleep(200);
                    SendEnMelding(sp, "$O51");                      //Skrur p� at d�ren er l�st
                    Thread.Sleep(200);
                    SendEnMelding(sp, "$O00");                      //Skrur av utgang 0
                    Thread.Sleep(200);
                    SendEnMelding(sp, "$O10");                      //Skrur av utgang 1
                    Thread.Sleep(200);
                    SendEnMelding(sp, "$O20");                      //Skrur av utgang 2
                    Thread.Sleep(200);
                    SendEnMelding(sp, "$O30");                      //Skrur av utgang 3
                }
            }
        }

        private void btn�pneD�r_Click_1(object sender, EventArgs e)
        {
            if (pinRiktig)                                          //Hvis Pin er riktig (boolsk verdi)
            {
                lbD�rStatus.Items.Insert(0, "D�r �pnet");           //Skriver til D�rstatus at d�ren er �pnet
                SendEnMelding(sp, "$O61");                          //Skriver til SimSim at d�ren er �pen

                txtPinKode.Text = "";
                btn�pneD�r.Enabled = false;                         //Gj�r det umulig � trykke p� �pneD�r igjen f�r den er lukket
                btnLukkD�r.Enabled = true;                          //Gj�r det mulig � trykke p� Lukk d�r knappen
                d�r�pen = true;                                     //Boolsk verdi for � telle tiden den er �pen
                pinRiktig = false;                                  //Setter boolsk verdi til false igjen for neste bruker
            }
            else
            {
                if (cbSeriellePorter.SelectedIndex >= 0)
                {
                    string comPort = cbSeriellePorter.SelectedItem.ToString();
                    kommuniser = true;

                    sp = new SerialPort(comPort, 9600);

                    try
                    {
                        sp.Open();
                    }
                    catch (Exception unntak)
                    {

                    }
                }
                lbAlarmStatus.Items.Insert(0, "D�r brutt opp!");    //Hvis d�ren er �pnet uten pin er den br�tet opp
                SendEnMelding(sp, "$O71");                          //Skriver alarm til SimSim
                SendEnMelding(sp, "$O50");
                SendEnMelding(sp, "$O61");
                SendEnMelding(sp, "$F500");

                tidligereKortID = lKortID[kj�ringer];
                tidligerPIN = lPIN[kj�ringer];


                tekstSomSkalSendes = "Alarm2" + "," + tidligerPIN + "," + "1234" + "," + tidligereKortID + "," + "2022-11-09 12:46:22" + "," + d�rNummer;
                backgroundWorker2.RunWorkerAsync();

                btn�pneD�r.Enabled = false;
                btnLukkD�r.Enabled = true;                          //Gj�r det mulig � lukke d�ren igjen
                d�r�pen = true;                                     //Boolsk variabel for � telle tiden d�ren er �pen
            }
        }


        private void btn0_Click(object sender, EventArgs e)
        {
            PIN = PIN + "0";                                        //Skriver til PIN vinduet hva vi har tastet
            tast0 = true;                                           //Boolsk variabel for � sende melding til SimSim at denne tasten er trykket

            SendEnMelding(sp, "$O01");
            Thread.Sleep(200);
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            PIN = PIN + "1";
            tast1 = true;

            SendEnMelding(sp, "$O11");
            Thread.Sleep(200);
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            PIN = PIN + "2";
            tast2 = true;

            SendEnMelding(sp, "$O21");
            Thread.Sleep(200);
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            PIN = PIN + "3";
            tast3 = true;

            SendEnMelding(sp, "$O31");
            Thread.Sleep(200);
        }

        private void txtPinKode_TextChanged(object sender, EventArgs e)
        {
            if (txtPinKode.TextLength == 4)
            {
                lPIN[kj�ringer] = PIN;
                tekstSomSkalSendes = "Validering" + "," + PIN + "," + "1234" + "," + kortID + "," + "2022-11-09 12:46:22" + "," + d�rNummer;
                backgroundWorker2.RunWorkerAsync();
            }
        }
        private void btnLukkD�r_Click_1(object sender, EventArgs e)
        {
            lbD�rStatus.Items.Insert(0, "D�r lukket");                          //Skriver i d�rstatus at d�rene er lukket
            lbD�rStatus.Items.Insert(0, "D�r l�st");                            //Skriver i d�rstatus at d�ren er l�st
            SendEnMelding(sp, "$O60");                                          //Sender melding til SimSim at d�ren er lukket
            Thread.Sleep(200);
            SendEnMelding(sp, "$O51");                                          //Sender melding til SimSim at d�ren er l�st
            Thread.Sleep(200);
            SendEnMelding(sp, "$O40");                                          //Skriver melding til SimSim at kort ikke er tappet
            Thread.Sleep(200);
            SendEnMelding(sp, "$O70");                                          //Skriver melding til SimSim at alarmen er skrudd av

            PIN = "";
            btnLukkD�r.Enabled = false;
            btnSettInnKort.Enabled = true;
            btn�pneD�r.Enabled = true;
            d�r�pen = false;
            TidIgjen = 45;
            txtKortID.Text = "";

            kommuniser = false;
            Thread.Sleep(500);
            sp.Close();
        }

        private void txtTid_TextChanged(object sender, EventArgs e)
        {

        }

        private void backgroundWorker2_DoWork(object sender, System.ComponentModel.DoWorkEventArgs e)
        {
            if (!ferdig)
            {
                SendTekst(klientSokkel, tekstSomSkalSendes, out ferdig);
            }

            if (!ferdig)
            {
                // Thread.Sleep(10000);  // om vi vil demonstrere "treig" Internet
                dataFraServer = MottaTekst(klientSokkel, out ferdig);
            }
        }

        private void backgroundWorker2_RunWorkerCompleted(object sender, System.ComponentModel.RunWorkerCompletedEventArgs e)
        {
            // Arbeid som utf�res av GUI-tr�den n�r bwHjelpetr�d_DoWork har avsluttet
            if (!ferdig)
            {
                mottattTekst = dataFraServer;
                lbFeilMeldinger.Items.Insert(0, mottattTekst);
            }
            if (mottattTekst == "Gyldig")                                           //Hvis PIN er riktig
            {
                btnSettInnKort.Enabled = false;
                btn�pneD�r.Enabled = true;
                pinRiktig = true;
                PIN = "";
                lbD�rStatus.Items.Insert(0, "Gyldig PIN");
                lbD�rStatus.Items.Insert(0, "D�r l�st opp");
                SendEnMelding(sp, "$O50");                              //Skriver til SimSim at d�ren er ul�st
                Thread.Sleep(200);
                tappetKort = false;
            }
            if (mottattTekst == "Ugyldig")
            {
                SendEnMelding(sp, "$O40");                          //Setter utgang til 0 at kortet ikke er tappet
                btnSettInnKort.Enabled = true;                      //Gj�r det mulig � trykke p� knappen igjen
                TidIgjen = 45;                                      //Setter tiden tilbake til 45 for nytt fors�k                      
                txtPinKode.Text = "";
                PIN = "";
                lbD�rStatus.Items.Insert(0, "Ugyldig PIN");
                tappetKort = false;
                kommuniser = false;
                sp.Close();                                         //Lukker koblingen s� ingenting g�r feil for neste bruker
            }

        }

        private void txtKortID_TextChanged(object sender, EventArgs e)
        {

        }
    }
}