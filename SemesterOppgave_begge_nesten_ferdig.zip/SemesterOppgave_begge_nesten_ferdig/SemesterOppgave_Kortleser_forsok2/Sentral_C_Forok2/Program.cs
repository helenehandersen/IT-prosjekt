﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
class EnkelTcpSrvr
{
    public static void Main()
    {
        // Server oppsett
        Socket lytteSokkel = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        IPEndPoint serverEP = new IPEndPoint(IPAddress.Parse("127.0.0.1"), 9050);
        lytteSokkel.Bind(serverEP);
        lytteSokkel.Listen(10);

        // Server aktivitet
        while (true)
        {
            // Venter på sklienter
            Console.WriteLine("Venter på en klient ...");
            Socket kommSokkel = lytteSokkel.Accept(); // blokkerende metode

            // Når en klient har tatt kontakt: info om kommunikasjon skrives ut
            VisKommunikasjonsinfo(kommSokkel);

            // Kommunikasjon med en klient fortsetter i en ny tråd
            ThreadPool.QueueUserWorkItem(KommunikasjonMedEnKlient, kommSokkel);
        }
        // lytteSokkel.Close();
    }

    static void KommunikasjonMedEnKlient(object arg)
    {
        Socket kommSokkel = arg as Socket;

        string mottattTekst = "";
        string tekstSomSkalSendes;

        bool ferdig = false;

        string hilsen = "Velkommen til en enkel testserver";
        SendTekst(kommSokkel, hilsen, out ferdig);

        while (!ferdig)
        {
            // Motta data fra en klient 
            mottattTekst = MottaTekst(kommSokkel, out ferdig);

            if (!ferdig)
            {
                // reverserer tekst som er mottatt
                string svar = "";

                string[] splittetTekst = mottattTekst.Split(",");

                if (splittetTekst[3] == "0000" && splittetTekst[1] == "0000") svar = "Gyldig";
                else if (splittetTekst[3] == "1111" && splittetTekst[1] == "0001") svar = "Gyldig";
                else if (splittetTekst[3] == "2222" && splittetTekst[1] == "0010") svar = "Gyldig";
                else if (splittetTekst[3] == "3333" && splittetTekst[1] == "0011") svar = "Gyldig";
                else svar = "Ugyldig";

                tekstSomSkalSendes = svar;
                Console.WriteLine(mottattTekst + svar);

                // Sende svar til klient
                SendTekst(kommSokkel, tekstSomSkalSendes, out ferdig);
            }
        }
        // Lukker kommunikasjonssokkel og viser info
        IPEndPoint klientEP = kommSokkel.RemoteEndPoint as IPEndPoint;
        Console.WriteLine("Forbindelsen med {0}:{1} er brutt", klientEP.Address, klientEP.Port);
        kommSokkel.Close();
    }

    static string MottaTekst(Socket kommSokkel, out bool feilHarOppstått)
    {
        string svar = "";
        feilHarOppstått = false;

        try
        {
            byte[] data = new byte[1024];
            int antallBytesMottatt = kommSokkel.Receive(data);

            if (antallBytesMottatt > 0) svar = Encoding.ASCII.GetString(data, 0, antallBytesMottatt);
            else feilHarOppstått = true;
        }
        catch (Exception unntak)
        {
            Console.WriteLine("Feil: " + unntak.Message);
            feilHarOppstått = true;
        }
        return svar;
    }

    static void SendTekst(Socket kommSokkel, string tekstSomSkalSendes, out bool feilHarOppstått)
    {
        feilHarOppstått = false;

        try
        {
            byte[] data = Encoding.ASCII.GetBytes(tekstSomSkalSendes);
            kommSokkel.Send(data, data.Length, SocketFlags.None);
        }
        catch (Exception unntak)
        {
            Console.WriteLine("Feil: " + unntak.Message);
            feilHarOppstått = true;
        }
    }

    static string ReverserTekst(string tekst)
    {
        string svar = "";
        Console.WriteLine(tekst);
        Char[] mottattArray = tekst.ToCharArray();
        Array.Reverse(mottattArray);
        StringBuilder sb = new StringBuilder();
        foreach (char ch in mottattArray)
            sb.Append(ch);
        svar = sb.ToString();
        return svar;
    }

    static void VisKommunikasjonsinfo(Socket s)
    {
        IPEndPoint klientEP = s.RemoteEndPoint as IPEndPoint;
        IPEndPoint serverEP = s.LocalEndPoint as IPEndPoint;
        Console.WriteLine("Kommunikasjon med klient: {0}:{1}", klientEP.Address, klientEP.Port);
        Console.WriteLine("Server bruker {0}:{1}", serverEP.Address, serverEP.Port);
    }
}