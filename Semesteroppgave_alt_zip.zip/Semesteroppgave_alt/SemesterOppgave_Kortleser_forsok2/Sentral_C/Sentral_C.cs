﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
class EnkelTcpKlient
{
    public static void Main()
    {
        string tekstSomSkalSendes, mottattTekst;
        bool ferdig = false;
        bool ingenKontaktMedServer = false;

        // Koble til serveren
        Socket klientSokkel = KobleTilServer(out ingenKontaktMedServer);
        if (!ingenKontaktMedServer)
        {
            // Motta velkomstmeldingen
            mottattTekst = MottaTekst(klientSokkel, out ferdig);
            Console.WriteLine(mottattTekst);

            while (!ferdig)
            {
                tekstSomSkalSendes = Console.ReadLine();
                if (tekstSomSkalSendes == "exit") ferdig = true;
                else
                {
                    SendTekst(klientSokkel, tekstSomSkalSendes, out ferdig);
                    if (!ferdig)
                    {
                        mottattTekst = MottaTekst(klientSokkel, out ferdig);
                        Console.WriteLine(mottattTekst);
                    }
                }
            }
            Console.WriteLine("Bryter forbindelsen med serveren ...");
            klientSokkel.Shutdown(SocketShutdown.Both);
            klientSokkel.Close();
        }

        // Console.ReadKey(true);
    }

    static Socket KobleTilServer(out bool ferdig)
    {
        ferdig = false;
        Socket klientSokkel = new Socket(AddressFamily.InterNetwork,
            SocketType.Stream,
            ProtocolType.Tcp);

        IPEndPoint serverEP = new IPEndPoint(IPAddress.Parse("127.0.0.1"), 9050);

        try
        {
            klientSokkel.Connect(serverEP); // blokkerende metode
        }
        catch (SocketException unntak)
        {
            Console.WriteLine("Fikk ikke forbindelse med server.");
            Console.WriteLine("Feil: " + unntak.ToString());
            ferdig = true;
        }

        return klientSokkel;
    }

    static string MottaTekst(Socket kommSokkel, out bool feilHarOppstått)
    {
        string svar = "";
        feilHarOppstått = false;

        try
        {
            byte[] data = new byte[1024];
            int antallBytesMottatt = kommSokkel.Receive(data);

            if (antallBytesMottatt > 0) svar = Encoding.ASCII.GetString(data, 0, antallBytesMottatt);
            else feilHarOppstått = true;
        }
        catch (Exception unntak)
        {
            Console.WriteLine("Feil: " + unntak.Message);
            feilHarOppstått = true;
        }
        return svar;
    }

    static void SendTekst(Socket kommSokkel, string tekstSomSkalSendes, out bool feilHarOppstått)
    {
        feilHarOppstått = false;

        try
        {
            byte[] data = Encoding.ASCII.GetBytes(tekstSomSkalSendes);
            kommSokkel.Send(data, data.Length, SocketFlags.None);
        }
        catch (Exception unntak)
        {
            Console.WriteLine("Feil: " + unntak.Message);
            feilHarOppstått = true;
        }
    }
}